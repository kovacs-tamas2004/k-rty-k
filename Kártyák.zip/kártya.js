let tomb = [];

function getInputValue(){
    let value = document.getElementById("text").value
    tomb.push(value);
    let tartalom = "";

    for(let i = 0; i < tomb.length; i++){
        tartalom += `<div class="doboz"><p>${tomb[i]}</p></div>`;
    }
    
    document.getElementById("adatok").innerHTML = tartalom;
}
